import React from "react";

const Utilities = () => {
  return <div>Utilities</div>;
};

export default Utilities;

// # to view this page, replace "%5F" with "_" in _utils
