import React from 'react'

const Science = () => {
  return (
    <div>Science</div>
  )
}

export default Science