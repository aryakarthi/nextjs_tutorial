import React from 'react'

const NotFound = () => {
  return (
    <div>Review Not Found</div>
  )
}

export default NotFound